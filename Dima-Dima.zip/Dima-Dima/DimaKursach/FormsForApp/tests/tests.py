import unittest

from DimaKursach.FormsForApp.encrypter import vigenere_encrypt, vigenere_decrypt


class encrypted(unittest.TestCase):
    def setUp(self):
        pass

    def test_encrypted1(self):
        result = vigenere_encrypt('dashdhaf', 'tusur')
        self.assertEqual('_(>\\(;(-', result)

    def test_encrypted2(self):
        result = vigenere_decrypt('_(>\\(;(-', 'tusur')
        self.assertEqual('dashdhaf', result)

    def test_encrypted3(self):
        result = vigenere_encrypt('ав', 'tusur')
        self.assertEqual('', result)

    def test_encrypted4(self):
        result = vigenere_decrypt('воыарыловраоы', 'киви')
        self.assertEqual('', result)

    def test_encrypted5(self):
        result = vigenere_encrypt('', 'tusur')
        self.assertEqual('', result)

    def test_encrypted6(self):
        result = vigenere_decrypt('Unitest', '')
        self.assertEqual('', result)

    def test_encrypted7(self):
        result = vigenere_encrypt('', '')
        self.assertEqual('', result)