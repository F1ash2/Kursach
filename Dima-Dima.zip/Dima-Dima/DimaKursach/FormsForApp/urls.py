from . import views
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('', views.showSignUpForm),
    path('CalcForm', views.showCalcForm),
    path('SignUp', views.SignUp),
    path('Function', views.Function),
    path('ShowData', views.showData),
    path('Messages', views.checkUserMessages)
]+ static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)