from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .models import User
from .models import Messaging
from django.db.utils import IntegrityError
from django.utils.datastructures import MultiValueDictKeyError
from django.contrib import messages
from django.core.files import File
from .forms import ShiphrForm
import os

def showSignUpForm(request):
    return render(request, 'SignUp.html')

def showCalcForm(request):
    return render(request, 'CalcForm.html')

def showData(request):
    return render(request, 'datas.html')

def checkUserMessages(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("pass")
        try:
            checkUserLogin = User.objects.get(Login=username, Password=password)
            if checkUserLogin is not None:
                datas = Messaging.objects.filter(Username_Id=checkUserLogin.id)
                return render(request, "datas.html", {"datas": datas})
            else:
                messages.error(request, "Wrong login or password")
                return HttpResponseRedirect("http://127.0.0.1:8000/ShowData")
        except User.DoesNotExist:
            messages.error(request, "Wrong login or password")
            return HttpResponseRedirect("http://127.0.0.1:8000/ShowData")
    return HttpResponseRedirect("http://127.0.0.1:8000/ShowData")

def SignUp(request):
    try:
        if request.method == "POST":
            user = User()
            checkLogin = request.POST.get("username")
            checkPass = request.POST.get("pass")
            if len(checkLogin) > 4 or len(checkPass) > 4:
                user.Login = request.POST.get("username")
                user.Password = request.POST.get("pass")
                user.save()
                return HttpResponseRedirect("http://127.0.0.1:8000/CalcForm")
            else:
                messages.error(request, 'Login and password must be over 4 letters')
                return redirect('http://127.0.0.1:8000/')
    except IntegrityError:
        messages.error(request, 'User with this login is already exist')
        return redirect('http://127.0.0.1:8000/')

def Function(request):
    form = ShiphrForm(request.POST, request.FILES or None)
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("pass")
        mes = request.POST.get('mes')
        key = request.POST.get('key')
        try:
            checkUserLogin = User.objects.get(Login=username, Password=password)
            rb = request.POST.get("RB", None)
            if rb in ["Decrypt", "Encrypt"]:
                if rb == "Encrypt":
                    if checkUserLogin is not None:
                        msg = mes
                        key = key
                        EncMes = vigenere_encrypt(msg, key)
                        if EncMes == '':
                            data = {
                                'username': username,
                                'password': password,
                                'mes': mes,
                                'key': key,
                                'result': EncMes
                            }
                            messages.error(request, 'Incorrect message or key')
                            return render(request, "CalcForm.html", data)
                        else:
                            tmp = Messaging.objects.create(Encrypted=EncMes, Message=msg, Username_Id=checkUserLogin.id)
                            data = {
                                'username': username,
                                'password': password,
                                'mes': mes,
                                'key': key,
                                'result': EncMes
                            }
                            try:
                                ChosenFile = request.FILES['chosenFile']
                                chosenFile = ChosenFile.name
                                path = os.path.abspath(chosenFile)
                                chsFile = open(path, 'a')
                                myfile = File(chsFile)
                                myfile.write("\nYour encrypted message: " + EncMes)
                                myfile.closed
                                return render(request, "CalcForm.html", data)
                            except MultiValueDictKeyError:
                                data = {
                                    'username': username,
                                    'password': password,
                                    'mes': mes,
                                    'key': key,
                                }
                                messages.error(request, 'You have not chosen file')
                                return render(request, "CalcForm.html", data)
                elif rb == "Decrypt":
                    if checkUserLogin is not None:
                        msg = mes
                        key = key
                        tmp = Messaging.objects.filter(Encrypted=msg, Username_Id=checkUserLogin.id)
                        tmp_list = list(tmp)
                        if len(tmp_list) > 0:
                            DecrMes = vigenere_decrypt(msg, key)
                            data = {
                                'username': username,
                                'password': password,
                                'mes': mes,
                                'key': key,
                                'result': DecrMes
                            }
                            return render(request, "CalcForm.html", data)
                        else:
                            messages.error(request, "Message is not found")
                            data = {
                                'username': username,
                                'password': password,
                                'mes': mes,
                                'key': key,
                            }
                            return render(request, "CalcForm.html", data)
        except User.DoesNotExist:
            messages.error(request, "Wrong login or password")
            return HttpResponseRedirect("http://127.0.0.1:8000/CalcForm")
    return HttpResponseRedirect("http://127.0.0.1:8000/CalcForm")

def vigenere_encrypt(message, key):
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz,.!?1234567890@#$%^&*()_-" \
               "+:;\/[]{}~`<>|"
    encrypted = ""

    for i in message:
        if i not in alphabet:
            return encrypted
    for i in key:
        if i not in alphabet:
            return encrypted

    if len(message) == 0 or len(key) == 0:
        return encrypted
    else:
        letter_to_index = dict(zip(alphabet, range(len(alphabet))))
        index_to_letter = dict(zip(range(len(alphabet)), alphabet))
        encrypted = ""
        split_message = [
            message[i: i + len(key)] for i in range(0, len(message), len(key))
        ]

        for each_split in split_message:
            i = 0
            for letter in each_split:
                number = (letter_to_index[letter] + letter_to_index[key[i]]) % len(alphabet)
                encrypted += index_to_letter[number]
                i += 1

        return encrypted

def vigenere_decrypt(cipher, key):
    alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz,.!?1234567890@#$%^&*()_-" \
               "+:;\/[]{}~`<>|"

    decrypted = ""

    for i in cipher:
        if i not in alphabet:
            return decrypted
    for i in key:
        if i not in alphabet:
            return decrypted

    if len(cipher) == 0 or len(key) == 0:
        return decrypted
    else:
        letter_to_index = dict(zip(alphabet, range(len(alphabet))))
        index_to_letter = dict(zip(range(len(alphabet)), alphabet))
        decrypted = ""
        split_encrypted = [
            cipher[i: i + len(key)] for i in range(0, len(cipher), len(key))
        ]

        for each_split in split_encrypted:
            i = 0
            for letter in each_split:
                number = (letter_to_index[letter] - letter_to_index[key[i]]) % len(alphabet)
                decrypted += index_to_letter[number]
                i += 1

        return decrypted
